# # yolov8_detector.py
# from ultralytics import YOLO
# import cv2

# # Load your trained model once
# model = YOLO('runs/bccd_yolov8/weights/best.pt')  # Adjust if needed

# def detect_and_save(input_path, output_path):
#     results = model(input_path)[0]
#     annotated_image = results.plot()
#     cv2.imwrite(output_path, annotated_image)
# yolov8_detector.py
from ultralytics import YOLO
import cv2
import os
from PIL import Image

model = YOLO('runs/bccd_yolov8/weights/best.pt')  # Adjust path if needed

def detect_and_save(input_path, output_path, wbc_crop_dir=None):
    results = model(input_path)[0]
    annotated_image = results.plot()
    cv2.imwrite(output_path, annotated_image)

    if wbc_crop_dir:
        # Clear previous crops
        for f in os.listdir(wbc_crop_dir):
            os.remove(os.path.join(wbc_crop_dir, f))

        os.makedirs(wbc_crop_dir, exist_ok=True)
        image = Image.open(input_path)

        for i, (box, cls) in enumerate(zip(results.boxes.xyxy, results.boxes.cls)):
            if int(cls) == 1:  # Class ID for WBC
                x1, y1, x2, y2 = map(int, box)
                crop = image.crop((x1, y1, x2, y2))
                crop_path = os.path.join(wbc_crop_dir, f'wbc_crop_{i}.jpg')
                crop.save(crop_path)
