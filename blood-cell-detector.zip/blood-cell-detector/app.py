from flask import Flask, render_template, request
import os
from werkzeug.utils import secure_filename
from yolov8_detector import detect_and_save
from keras.models import load_model
from PIL import Image
import numpy as np

# Initialize Flask app
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static/uploads/'
app.config['OUTPUT_FOLDER'] = 'static/outputs/'
app.config['WBC_CROP_FOLDER'] = 'static/wbc_crops/'

# Create directories if they don't exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['OUTPUT_FOLDER'], exist_ok=True)
os.makedirs(app.config['WBC_CROP_FOLDER'], exist_ok=True)

# Load WBC classifier model
wbc_model = load_model("blood-cell-detector/scripts/wbc_cnn_rnn_model.h5")
wbc_labels = ['eosinophil', 'lymphocyte', 'monocyte', 'neutrophil']

# Preprocess and predict WBC crop
def classify_wbc_subtypes(crop_dir):
    predictions = []
    for filename in sorted(os.listdir(crop_dir)):
        if filename.endswith(".jpg"):
            path = os.path.join(crop_dir, filename)
            print(f"Processing: {path}")
            image = Image.open(path).resize((128, 128))  # Adjust size as per your model

            img_array = np.array(image) / 255.0
            if img_array.shape[-1] != 3:
                img_array = np.stack((img_array,) * 3, axis=-1)  # convert to RGB if grayscale

            img_array = np.expand_dims(img_array, axis=0)

            pred = wbc_model.predict(img_array)[0]
            label = wbc_labels[np.argmax(pred)]
            print(f"{filename} → {label}")
            predictions.append((filename, label))
    return predictions

@app.route('/', methods=['GET', 'POST'])
def index():
    input_image = None
    output_image = None
    wbc_predictions = []

    if request.method == 'POST':
        file = request.files['image']
        if file:
            filename = secure_filename(file.filename)
            input_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            output_path = os.path.join(app.config['OUTPUT_FOLDER'], filename)

            # Clear old crops
            for old in os.listdir(app.config['WBC_CROP_FOLDER']):
                os.remove(os.path.join(app.config['WBC_CROP_FOLDER'], old))

            file.save(input_path)
            detect_and_save(input_path, output_path, app.config['WBC_CROP_FOLDER'])

            input_image = filename
            output_image = filename
            wbc_predictions = classify_wbc_subtypes(app.config['WBC_CROP_FOLDER'])
            print("Predictions:", wbc_predictions)

    return render_template('index.html',
                           input_image=input_image,
                           output_image=output_image,
                           wbc_predictions=wbc_predictions)

if __name__ == '__main__':
    app.run(debug=True)
