from ultralytics import YOLO

# Load a pre-trained model (nano version; you can use 'yolov8s.pt', 'm.pt', etc.)
model = YOLO('yolov8n.pt')

# Train the model
model.train(
    data='bccd.yaml',
    epochs=10,
    imgsz=640,
    batch=16,
    project='runs',
    name='bccd_yolov8',
    exist_ok=True
)
