from ultralytics import YOLO
import cv2

# Load your best trained model
model = YOLO('runs/bccd_yolov8/weights/best.pt')


# Predict on an image
results = model('C:/Users/K jagadeesu/Downloads/BCCD_Dataset-master/BCCD_Dataset-master/BCCD/JPEGImages/BloodImage_00360.jpg')  # Replace with your image path




# Show image with detections
results[0].show()  # Display in a window
results[0].save(filename='predicted.jpg')  # Save the result
