import os
import shutil
import xml.etree.ElementTree as ET

# Class names used in the dataset
classes = ['RBC', 'WBC', 'Platelets']

# VOC annotation and image paths
input_dir = 'BCCD_Dataset/BCCD/Annotations'
image_source_dir = 'BCCD_Dataset/BCCD/JPEGImages'

# Output directories for YOLO format
output_dir = 'dataset/labels'
image_dir = 'dataset/images' 

os.makedirs(f'{output_dir}/train', exist_ok=True)
os.makedirs(f'{output_dir}/val', exist_ok=True)
os.makedirs(f'{image_dir}/train', exist_ok=True)
os.makedirs(f'{image_dir}/val', exist_ok=True)

# Function to convert bounding box to YOLO format
def convert(size, box):
    dw = 1. / size[0]
    dh = 1. / size[1]
    x = (box[0] + box[1]) / 2.0 * dw
    y = (box[2] + box[3]) / 2.0 * dh
    w = (box[1] - box[0]) * dw
    h = (box[3] - box[2]) * dh
    return x, y, w, h

# Get all annotation filenames
all_files = [f.replace('.xml', '') for f in os.listdir(input_dir) if f.endswith('.xml')]
split = int(0.8 * len(all_files))
train_files = all_files[:split]
val_files = all_files[split:]

# Process training and validation sets
for phase, file_list in zip(['train', 'val'], [train_files, val_files]):
    for filename in file_list:
        in_file_path = os.path.join(input_dir, f'{filename}.xml')
        out_file_path = os.path.join(output_dir, phase, f'{filename}.txt')

        tree = ET.parse(in_file_path)
        root = tree.getroot()
        size = root.find('size')
        w = int(size.find('width').text)
        h = int(size.find('height').text)

        with open(out_file_path, 'w') as out_file:
            for obj in root.iter('object'):
                cls = obj.find('name').text
                if cls not in classes:
                    continue
                cls_id = classes.index(cls)
                xmlbox = obj.find('bndbox')
                b = (
                    float(xmlbox.find('xmin').text),
                    float(xmlbox.find('xmax').text),
                    float(xmlbox.find('ymin').text),
                    float(xmlbox.find('ymax').text)
                )
                bb = convert((w, h), b)
                out_file.write(f"{cls_id} {' '.join([str(round(a, 6)) for a in bb])}\n")

        # Copy corresponding image to output folder
        src_img = os.path.join(image_source_dir, f'{filename}.jpg')
        dst_img = os.path.join(image_dir, phase, f'{filename}.jpg')
        shutil.copy(src_img, dst_img)

print("✅ Conversion completed! YOLO-formatted data is in the 'dataset' folder.")
